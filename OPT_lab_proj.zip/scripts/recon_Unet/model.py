import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    """
    CARE 的标准卷积块：Conv -> BN -> ReLU -> Conv -> BN -> ReLU
    """

    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),  # CSBDeep 默认包含 BN
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)


class CARE_UNet(nn.Module):
    def __init__(self, n_channels, n_classes, base_filters=32):
        """
        CARE 风格的 U-Net
        :param n_channels: 输入通道数 (如 FPM 的 4 张图)
        :param n_classes: 输出通道数 (如复数的实部+虚部 为 2)
        :param base_filters: 起始滤波器数量，CARE 默认为 32
        """
        super(CARE_UNet, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes

        # --- 下采样路径 (Encoder) ---
        # Depth 0
        self.inc = ConvBlock(n_channels, base_filters)

        # Depth 1
        self.down1_pool = nn.MaxPool2d(2)
        self.down1_conv = ConvBlock(base_filters, base_filters * 2)

        # Depth 2 (Bridge / Bottleneck)
        # CARE 默认深度为 2，这里就是最底层
        self.down2_pool = nn.MaxPool2d(2)
        self.down2_conv = ConvBlock(base_filters * 2, base_filters * 4)

        # --- 上采样路径 (Decoder) ---
        # Up 1 (对应 Depth 1)
        # CARE 使用 Upsample (双线性插值) 而不是转置卷积
        self.up1 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.up1_conv = ConvBlock(base_filters * 4 + base_filters * 2, base_filters * 2)  # Concat 后通道数增加

        # Up 0 (对应 Depth 0)
        self.up2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.up2_conv = ConvBlock(base_filters * 2 + base_filters, base_filters)

        # --- 输出层 ---
        # CARE 最后一层是 1x1 卷积，线性激活
        self.outc = nn.Conv2d(base_filters, n_classes, kernel_size=1)

    def forward(self, x):
        # 记录输入用于残差连接 (如果输入输出通道数一致)
        input_image = x

        # --- Encoder ---
        x0 = self.inc(x)  # Level 0: 32

        x1_pool = self.down1_pool(x0)
        x1 = self.down1_conv(x1_pool)  # Level 1: 64

        x2_pool = self.down2_pool(x1)
        x2 = self.down2_conv(x2_pool)  # Level 2: 128 (Bridge)

        # --- Decoder ---
        # Up 1
        x_up1 = self.up1(x2)
        # Skip Connection: 拼接 x1
        x_up1 = torch.cat([x_up1, x1], dim=1)
        x_dec1 = self.up1_conv(x_up1)

        # Up 2
        x_up2 = self.up2(x_dec1)
        # Skip Connection: 拼接 x0
        x_up2 = torch.cat([x_up2, x0], dim=1)
        x_dec0 = self.up2_conv(x_up2)

        # --- Output ---
        logits = self.outc(x_dec0)

        # --- CARE 核心特征：残差连接 (Residual Connection) ---
        # 网络的任务是去噪/复原，所以输出 = 输入 + 预测的残差
        # 只有当输入通道数 == 输出通道数时才能直接相加 (比如输入1张脏图，输出1张净图)
        if self.n_channels == self.n_classes:
            return input_image + logits
        else:
            # 如果通道数不一样 (比如FPM输入4张，输出2张)，则无法直接残差相加
            # 这种情况下直接返回网络输出
            return logits