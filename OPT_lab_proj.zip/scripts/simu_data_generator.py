import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from numpy.fft import fft2, fftshift, ifftshift
import math
from scipy.ndimage import zoom, gaussian_filter
from scipy.misc import ascent
from Optlab import (
    calculate_tcc_modes_with_source,
    simulate_imaging_TCCmodes,
    load_complex_object,
    generate_source,
    save_as_NPY,
    save_as_PNG
)


# 0.系统参数初始化
print('--- 0.参数初始化 ---')
# 硬件参数
wavelength = 532e-9
NA_obj = 0.382
dxd = (326.6e-6 / 3000) * 2
z_led = 17.2e-3
# 仿真参数
calc_grid_size = 128
n_modes_out = 8
size_obj = 2048
print('--- 1.读取物体图像 ---')
obj = load_complex_object(
    obj_folder='images/source',
    obj_name='obj1',
    target_size=size_obj)
# 光源建模
print('--- 2.构建1/4光源序列 ---')
num_source = 4
size_source = 512
delta_source = 50e-6
all_source_data = []
all_vals = []
all_modes = []
all_source_k = []
for i in range(num_source):
    print(f"---- 2.{i+1}: 正在构建中.... {i+1} / 4 --")
    # 2.1 生成光源空间分布
    source_data_i = generate_source(
        size_source=size_source,
        delta_source=delta_source,
        radius=7.6e-3,
        quadrant_mode=i+1,        # 1,2,3,4对应上右下左(顺时针)
        angle=225,
        sigma=250e-6,         # 输入物理平滑尺寸
        intensity=1.0
    )
    # 2.2 生成TCC光瞳模式
    vals_i, modes_i, p_phy_i, source_k_i = calculate_tcc_modes_with_source(
        source_data=source_data_i,
        delta_source=delta_source,
        wavelength=wavelength,
        NA_obj=NA_obj,
        z_led=z_led,
        target_grid_size=size_obj,
        calc_grid_size=calc_grid_size,
        dxd=dxd,
        n_modes_out=n_modes_out
    )
    all_source_data.append(source_data_i)
    all_vals.append(vals_i)
    all_modes.append(modes_i)
    all_source_k.append(source_k_i)

source_data = np.array(all_source_data)
vals = np.array(all_vals)
modes = np.array(all_modes)
source_k = np.array(all_source_k)

# 3. 拓展光源成像
print("--- 3.拓展光源成像 ---")
all_img = []
for i in range(num_source):
    img_i = simulate_imaging_TCCmodes(
        modes=modes[i],
        values=vals[i],
        obj=obj,
        noise_config={
            'gaussian_factor': 0.008,
            'poisson_factor': 0.014
        }
    )
    #all_img.append(np.sqrt(img_i))
    all_img.append(img_i)
img = np.array(all_img)


# 4. 结果展示
print('--- 4.结果展示 ---')
roi_x = 150   # ROI起始 x 坐标 (列)
roi_y = 400   # ROI起始 y 坐标 (行)
roi_w = 200   # ROI 宽度
roi_h = 200   # ROI 高度

def get_roi(img_data):
    return img_data[roi_y:roi_y+roi_h, roi_x:roi_x+roi_w]

fig, axes = plt.subplots(3, 5, figsize=(20, 12)) # 设置画布大小
# 绘制光源k域分布
axes[0, 0].axis('off')
axes[0, 0].text(0.5, 0.5, "Source K-Field\n(Row 1)", ha='center', va='center', fontsize=12)
for i in range(num_source):
    ax = axes[0, i + 1]
    src_k = source_k[i]
    ax.imshow(src_k, cmap='inferno')
    ax.set_title(f"Source {i + 1} (K)", fontsize=10)
    ax.axis('off')
# 绘制成像结果图
ax_obj = axes[1, 0]
obj_amp = np.abs(obj)
ax_obj.imshow(obj_amp, cmap='gray')
ax_obj.set_title("Ground Truth of E_obj (Full)", fontsize=10)
ax_obj.axis('off')
rect = patches.Rectangle((roi_x, roi_y), roi_w, roi_h, linewidth=2, edgecolor='r', facecolor='none')
ax_obj.add_patch(rect)
for i in range(num_source):
    ax = axes[1, i + 1]
    # img_stack 是 (H, W, N)
    E_val = np.sqrt(img[i])

    ax.imshow(E_val, cmap='gray')
    ax.set_title(f"E_{i + 1} (Full)", fontsize=10)
    ax.axis('off')
# 绘制成像结果ROI图
ax_obj_roi = axes[2, 0]
ax_obj_roi.imshow(get_roi(obj_amp), cmap='gray')
ax_obj_roi.set_title("GT ROI", fontsize=10)
ax_obj_roi.axis('off')
for spine in ax_obj_roi.spines.values():
    spine.set_edgecolor('red')
    spine.set_linewidth(2)
for i in range(num_source):
    ax = axes[2, i + 1]
    E_val = np.sqrt(img[i])
    ax.imshow(get_roi(E_val), cmap='gray')
    ax.set_title(f"Image {i + 1} ROI", fontsize=10)
    ax.axis('off')
# 绘图结果保存
plt.tight_layout()
save_path = 'images/result_comparison.png'
plt.savefig(
    save_path,
    dpi=300,
    bbox_inches='tight',
    pad_inches=0.1,
    transparent=False
)
print(f"对比图已保存至: {save_path}")
plt.show()

# 数据保存

print('--- 5.数据保存 ---')
print(f"shape of obj : {obj.shape}")
print(f"shape of IMG : {img.shape}")
save_dir = './images/dataset/raw'
save_as_NPY(obj, save_dir=save_dir, save_name='obj_sim_1')
save_as_NPY(img, save_dir=save_dir, save_name='img_sim_1')

