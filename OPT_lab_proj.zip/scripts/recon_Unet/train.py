import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from model import CARE_UNet
from dataset import FPMDataset
import os

# 定义相关函数
def visualize_train_batch(loader, num_samples=8):
    """
    可视化 DataLoader 中的样本：
    - 左侧 4 列：信息量最丰富 (GT方差最大) 的样本
    - 右侧 4 列：信息量最贫乏 (GT方差最小) 的样本
    """
    # 1. 从 Loader 中提取一个 Batch
    # imgs: (Batch, 4, H, W), gt: (Batch, 2, H, W)
    imgs, gt_complex = next(iter(loader))

    # 2. 转换数据
    imgs = imgs.cpu().numpy()
    gt_complex = gt_complex.cpu().numpy()
    batch_size = imgs.shape[0]

    # ---  计算信息量并排序 ---
    scores = []
    for k in range(batch_size):
        # 计算 GT 的幅值
        amp = np.sqrt(gt_complex[k, 0] ** 2 + gt_complex[k, 1] ** 2)
        # 计算方差作为“信息量”指标
        scores.append(np.var(amp))

    scores = np.array(scores)
    sorted_indices = np.argsort(scores)  # 从小到大排序

    # 选取索引
    if batch_size < 8:
        print(f"Warning: Batch size ({batch_size}) is less than 8. Showing all.")
        indices_to_show = np.arange(batch_size)
    else:
        # 取最大的4个 (倒序取，变成从大到小)
        top_4 = sorted_indices[-4:][::-1]
        # 取最小的4个
        bottom_4 = sorted_indices[:4]
        # 拼接：左边是Top4，右边是Bottom4
        indices_to_show = np.concatenate([top_4, bottom_4])

    actual_samples = len(indices_to_show)

    # 3. 绘图配置
    plt.figure(figsize=(actual_samples * 2, 10))

    for col_idx, batch_idx in enumerate(indices_to_show):
        # batch_idx 是该样本在原始 batch 中的索引

        # --- 第一行：GT 真值 ---
        gt_amp = np.sqrt(gt_complex[batch_idx, 0] ** 2 + gt_complex[batch_idx, 1] ** 2)

        plt.subplot(5, actual_samples, col_idx + 1)
        plt.imshow(gt_amp, cmap='gray')
        plt.axis('off')

        # 设置标题区分
        if col_idx == 0:
            plt.title("High Info (Top)", fontsize=10, color='red')
        elif col_idx == 4:  # 第5列开始是低信息量
            plt.title("Low Info (Bottom)", fontsize=10, color='blue')

        # --- 第2~5行：对应的 4 张输入图 ---
        for j in range(4):
            # 子图索引 = 行号 * 列总数 + 当前列 + 1
            plt.subplot(5, actual_samples, (j + 1) * actual_samples + col_idx + 1)
            plt.imshow(imgs[batch_idx, j], cmap='gray')
            plt.axis('off')
            if col_idx == 0:
                plt.title(f"Input {j + 1}", fontsize=10, loc='left')

    plt.tight_layout()
    print("Close the plot window to continue training...")
    plt.show()
# === 1. 参数设置 ===
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# 数据读写路径
obj_path = '../images/dataset/raw/obj_sim_1.npy'
img_path = '../images/dataset/raw/img_sim_1.npy'
train_path = ''
current_dir = os.path.dirname(os.path.abspath(__file__))
save_dir = os.path.join(current_dir, 'checkpoint')
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
    print(f"Created result directory: {save_dir}")
model_dir = os.path.join(current_dir, 'model')
if not os.path.exists(model_dir):
    os.makedirs(model_dir)
    print(f"Created result directory: {model_dir}")
model_name = 'CARE_UNet_123'
LR = 0.001  # 训练学习率
EPOCHS = 500  # 迭代轮次
BATCH_SIZE = 16  # 迭代批次
N_INPUTS = 4  # 输入4张强度图像
N_OUTPUTS = 2  # 输出实部+虚部图像（是否有改进）
ROI_SIZE = 64  # ROI块裁切大小
STRIDE = 32  # 分块扫描步长
NUM_PATCHES = 64  # ROI块数量
# === 2. 训练数据初始化 ===
train_dataset = FPMDataset(
    obj_path=obj_path,
    img_path=img_path,
    roi_size=ROI_SIZE,  # ROI块裁切大小
    stride=STRIDE,  # 分块扫描步长
    num_patches=NUM_PATCHES  # ROI块数量
)
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
# 训练数据可视化
print("Visualizing dataset samples...")
visualize_train_batch(train_loader, num_samples=8)
# === 3. 模型初始化 ===
model = CARE_UNet(n_channels=N_INPUTS, n_classes=N_OUTPUTS)
model = model.to(DEVICE)

# === 4. 设置Loss函数 ===
#  L1 Loss = |Pred_re - GT_re| + |Pred_im - GT_im|
criterion = torch.nn.L1Loss()

# === 5. 优化器初始化 ===
optimizer = optim.Adam(model.parameters(), lr=LR)
loss_history = []
# === 6. 模型训练 ===
print(f"Start Training on {DEVICE}...")
print(f"Train Set Size: {len(train_dataset)}")

for epoch in range(EPOCHS):
    model.train()
    epoch_loss = 0

    for i, (imgs, gt_complex) in enumerate(train_loader):
        # imgs shape: (Batch, 4, ROI_SIZE, ROI_SIZE)
        # gt_complex shape: (Batch, 2, ROI_SIZE, ROI_SIZE)
        imgs = imgs.to(DEVICE)
        gt_complex = gt_complex.to(DEVICE)
        # 前向传播
        output = model(imgs)  # 输出 (Batch, 2, ROI_SIZE, ROI_SIZE)
        # 计算 Loss
        loss = criterion(output, gt_complex)
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
    # 训练可视化
    avg_loss = epoch_loss / len(train_loader)
    print(f"Epoch {epoch + 1}/{EPOCHS}, Loss: {avg_loss:.6f}")
    loss_history.append(avg_loss)
    # 保存10次模型
    epoch_disp = int(EPOCHS/10)
    if (epoch + 1) % epoch_disp == 0:
        # 保存模型权重
        save_name = os.path.join(save_dir, f'fpm_unet_epoch_{epoch + 1}.pth')
        torch.save(model.state_dict(), save_name)
        print(f"Model Saved: {save_name}")
print("Training Finished!")
# 保存最终模型
model_name = 'CARE_UNet_123'
model_path = os.path.join(model_dir, f'{model_name}.pth')
torch.save(model.state_dict(), model_path)
print(f" Final Model {model_name} saved to {model_path}")

# 绘制loss
plt.figure(figsize=(5, 3))
plt.plot(range(1, len(loss_history) + 1), loss_history, label='Train Loss', color='blue')
#plt.semilogy(range(1, len(loss_history) + 1),loss_history, label='Train Loss', color='blue')
plt.xlabel('Epochs')
plt.ylabel('L1 Loss')
plt.title('Training Loss Curve')
plt.legend()
plt.grid(True)
plt.show()
# 保存loss曲线
plot_path = os.path.join(save_dir, 'final_loss_curve.png')
plt.savefig(plot_path)
plt.close()
# 保存loss数据
history_path = os.path.join(save_dir, 'final_loss_history.npy')
np.save(history_path, np.array(loss_history))
print(f" Loss curve saved to: {plot_path}")
print(f" Loss data saved to: {history_path}")