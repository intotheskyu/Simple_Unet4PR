import torch
import numpy as np
import matplotlib.pyplot as plt
import os
from model import CARE_UNet

# === 1. 参数设置 ===
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 模型参数
model_name = 'CARE_UNet_123'
N_INPUTS = 4  # 输入4张图
N_OUTPUTS = 2  # 输出实部+虚部
ROI_SIZE = 1024  # 测试时的裁切大小 (可以和训练不同，但建议一致)

# 路径设置
# 获取当前脚本所在目录
current_dir = os.path.dirname(os.path.abspath(__file__))

# 数据路径
obj_path = os.path.join(current_dir, '../images/dataset/test/obj_sim_1.npy')
img_path = os.path.join(current_dir, '../images/dataset/test/img_sim_1.npy')

# 模型权重路径
MODEL_PATH = os.path.join(current_dir, 'model', f"{model_name}.pth")


def load_data_and_crop(obj_file, img_file, crop_y, crop_x, size):
    """
    加载测试图，并裁切指定位置进行测试
    """
    print(f"Loading data from:\n  GT: {obj_file}\n  In: {img_file}")

    # 1. 加载数据
    full_gt = np.load(obj_file)  # (H, W) Complex
    full_img = np.sqrt(np.load(img_file))  # (4, H, W) Real

    # 2. 裁切 ROI
    # 确保不越界
    max_h, max_w = full_gt.shape
    if crop_y + size > max_h or crop_x + size > max_w:
        raise ValueError("Crop region is out of bounds!")

    gt_patch = full_gt[crop_y:crop_y + size, crop_x:crop_x + size]
    input_patch = full_img[:, crop_y:crop_y + size, crop_x:crop_x + size]

    return input_patch, gt_patch


def preprocess_input(img_patch):
    """
    (C, H, W) numpy -> (1, C, H, W) Tensor
    """
    # 转为 Tensor
    input_tensor = torch.from_numpy(img_patch).float()
    # 增加 Batch 维度: (C, H, W) -> (1, C, H, W)
    input_tensor = input_tensor.unsqueeze(0)
    return input_tensor


def postprocess_output(output_tensor):
    """
    (1, 2, H, W) Tensor -> (H, W) Complex Numpy
    """
    # 去掉 Batch 维度，转为 Numpy
    # output shape: (1, 2, H, W) -> (2, H, W)
    pred_data = output_tensor.squeeze(0).cpu().numpy()

    # 分离实部和虚部
    pred_real = pred_data[0, :, :]
    pred_imag = pred_data[1, :, :]

    # 合并为复数
    pred_complex = pred_real + 1j * pred_imag

    return pred_complex


def visualize_comparison(input_patch, gt_complex, pred_complex):
    """
    可视化对比：输入、真值(幅值/相位)、预测(幅值/相位)
    """
    # 计算幅值和相位
    gt_amp = np.abs(gt_complex)
    gt_phase = np.angle(gt_complex)

    pred_amp = np.abs(pred_complex)
    pred_phase = np.angle(pred_complex)

    # 开始绘图
    plt.figure(figsize=(12, 8))

    # --- Row 1: Inputs (显示前2张作为代表) ---
    plt.subplot(2, 4, 1)
    plt.imshow(input_patch[0], cmap='gray')
    plt.title("Input LED 1 (Low Res)")
    plt.axis('off')

    plt.subplot(2, 4, 2)
    plt.imshow(input_patch[1], cmap='gray')
    plt.title("Input LED 2 (Low Res)")
    plt.axis('off')

    # --- Row 1: GT ---
    plt.subplot(2, 4, 3)
    plt.imshow(gt_amp, cmap='gray')
    plt.title("GT Amplitude")
    plt.axis('off')

    plt.subplot(2, 4, 4)
    plt.imshow(gt_phase, cmap='gray')
    plt.title("GT Phase")
    plt.axis('off')

    # --- Row 2: Prediction ---
    plt.subplot(2, 4, 7)
    plt.imshow(pred_amp, cmap='gray')
    plt.title("Pred Amplitude")
    plt.axis('off')

    plt.subplot(2, 4, 8)
    plt.imshow(pred_phase, cmap='gray')
    plt.title("Pred Phase")
    plt.axis('off')

    # --- Row 2: Error Map (Amplitude) ---
    plt.subplot(2, 4, 6)
    error_map = np.abs(gt_amp - pred_amp)
    plt.imshow(error_map, cmap='inferno')
    plt.title("Error Map (Amp)")
    plt.axis('off')
    plt.colorbar(fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.show()


def main():
    # === 2. 加载模型 ===
    print(f"Loading model from {MODEL_PATH} ...")
    model = CARE_UNet(n_channels=N_INPUTS, n_classes=N_OUTPUTS)

    # 加载权重
    if os.path.exists(MODEL_PATH):
        checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)
        model.load_state_dict(checkpoint)
        print("Model weights loaded successfully.")
    else:
        print(f"Error: Model file not found at {MODEL_PATH}")
        return

    model = model.to(DEVICE)
    model.eval()  # 切换到评估模式

    # === 3. 准备测试数据 ===
    # 这里我们随机选一个坐标，或者你可以指定坐标
    # 例如：选择图像中心区域
    # crop_y, crop_x = 1024, 1024
    # 或者随机：
    crop_y = np.random.randint(0, 2048 - ROI_SIZE)
    crop_x = np.random.randint(0, 2048 - ROI_SIZE)

    print(f"Testing ROI at position: y={crop_y}, x={crop_x}")

    input_patch, gt_complex = load_data_and_crop(
        obj_path, img_path, crop_y, crop_x, ROI_SIZE
    )

    # 预处理
    input_tensor = preprocess_input(input_patch).to(DEVICE)

    # === 4. 推理 ===
    print("Running inference...")
    with torch.no_grad():
        output_tensor = model(input_tensor)
    # === 5. 后处理与可视化 ===
    pred_complex = postprocess_output(output_tensor)
    print("Visualizing results...")
    visualize_comparison(input_patch, gt_complex, pred_complex)


if __name__ == '__main__':
    main()