import torch
from torch.utils.data import Dataset
import numpy as np
import os

class FPMDataset(Dataset):
    def __init__(self, obj_path, img_path, roi_size=48, stride=48, num_patches=1000):
        """
        初始化数据集，选取信息量最大的 Top-N 个数据块。
        Args:
            obj_path (str): obj_sim_1.npy 路径
            img_path (str): img_sim_1.npy 路径

            roi_size (int): 切块大小
            stride (int): 滑窗步长
            num_patches (int): 固定选取的 ROI 数量（即 num_pitch）。
                               程序会自动选取幅值方差最大的前 num_patches 个块。
        """
        super().__init__()

        # 1. 加载图像数据
        print(f"正在加载数据...\n  GT: {obj_path}\n  Input: {img_path}")
        self.full_obj = np.load(obj_path)  # (2048, 2048) complex
        self.full_img = np.sqrt(np.load(img_path))  # (4, 2048, 2048) real
        self.roi_size = roi_size
        self.input_patches = []
        self.gt_patches = []

        # 2. ROI裁切
        print(f"数据分块 (Target Num={num_patches}, Stride={stride})...")
        self._create_patches(stride, num_patches)

        self.input_patches = np.array(self.input_patches)
        self.gt_patches = np.array(self.gt_patches)

        print(f"数据集构建完成！实际生成 {len(self.gt_patches)} 个训练样本。")
        print(f"Input Shape: {self.input_patches.shape}")
        print(f"GT Shape:    {self.gt_patches.shape}")
        # 数据保存test
        save_dir = '../scripts/images/dataset/train'
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        print(f"正在将本轮生成的数据保存至: {save_dir} ...")
        np.save(os.path.join(save_dir, 'train_obj_sim_1.npy'), np.array(self.gt_patches))
        np.save(os.path.join(save_dir, 'train_img_sim_1.npy'), np.array(self.input_patches))
        print("数据保存完成！")

    def _create_patches(self, stride, num_patches):
        """
        获取ROI区域用于训练
        """
        H, W = self.full_obj.shape
        candidates = []  # 临时存放 (方差, y, x)
        # 遍历图像块方差
        for y in range(0, H - self.roi_size + 1, stride):
            for x in range(0, W - self.roi_size + 1, stride):
                gt_patch = self.full_obj[y:y + self.roi_size, x:x + self.roi_size]
                score = np.var(np.abs(gt_patch))
                candidates.append((score, y, x))

        # 根据方差选取ROI序列
        candidates.sort(key=lambda x: x[0], reverse=True)
        top_candidates = candidates[:num_patches]
        if len(top_candidates) < num_patches:
            print(f"[警告] 图片太小或步长太大，只能生成 {len(top_candidates)} 个块，无法满足 {num_patches} 个的要求。")

        # 读取存储ROI序列
        for score, y, x in top_candidates:
            gt_patch = self.full_obj[y:y + self.roi_size, x:x + self.roi_size]
            img_patch = self.full_img[:, y:y + self.roi_size, x:x + self.roi_size]
            self.input_patches.append(img_patch)
            self.gt_patches.append(gt_patch)

    def __len__(self):
        return len(self.gt_patches)

    def __getitem__(self, idx):
        # 数据读取
        input_data = self.input_patches[idx]
        gt_data = self.gt_patches[idx]

        # 数据增强接口（加噪声，动态范围变化，旋转。。。）
        # noise_level = np.random.uniform(0.001, 0.01)
        # input_data = input_data + np.random.normal(0, noise_level, input_data.shape)
        # 转化Tensor
        input_tensor = torch.from_numpy(input_data).float()

        # GT 拆分为实部虚部
        gt_real = torch.from_numpy(gt_data.real).float().unsqueeze(0)
        gt_imag = torch.from_numpy(gt_data.imag).float().unsqueeze(0)
        gt_tensor = torch.cat([gt_real, gt_imag], dim=0)

        return input_tensor, gt_tensor