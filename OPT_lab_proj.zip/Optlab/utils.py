import numpy as np
import cv2
import os
from scipy.ndimage import gaussian_filter


def load_complex_object(obj_folder, obj_name, target_size=1024):
    """
    读取振幅和相位图片，合成为复数物体。
    Args:
        obj_folder (str): 图片所在的文件夹路径
        obj_name (str): 图片文件名前缀 (程序将寻找 {obj_name}_amp.png 和 {obj_name}_phi.png)
        target_size (int): 目标网格尺寸 (默认 1024)
    Returns:
        obj (np.ndarray): 合成后的复数物体 (complex128)
    """

    # 1. 构建文件路径
    path_amp = os.path.join(obj_folder, f"{obj_name}_amp.png")
    path_phi = os.path.join(obj_folder, f"{obj_name}_phi.png")
    print(f"\n--- 正在加载复数物体: {obj_name} ---")
    # 定义一个内部辅助函数来处理单张图片的读取、打印和归一化
    def read_process_norm(path, label):
        if not os.path.exists(path):
            raise FileNotFoundError(f"[{label}] 文件未找到: {path}")
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError(f"[{label}] 读取失败 (格式错误?): {path}")

        # 确保是单通道灰度图
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 【展示】打印原始数据范围
        raw_min, raw_max = img.min(), img.max()
        dtype = img.dtype
        print(f"[{label}] 原始数据范围: min={raw_min}, max={raw_max}, dtype={dtype}")

        # 归一化逻辑 (转为 0.0 - 1.0)
        img_float = img.astype(np.float64)
        if dtype == np.uint16:
            obj_norm = img_float / 65535.0
        elif dtype == np.uint8:
            obj_norm = img_float / 255.0
        else:
            # 其他格式，按最大值归一化
            obj_norm = img_float / (raw_max if raw_max > 0 else 1.0)

        if obj_norm.shape[0] != target_size or obj_norm.shape[1] != target_size:
            # 使用线性插值调整大小
            obj_norm = cv2.resize(obj_norm, (target_size, target_size), interpolation=cv2.INTER_LINEAR)

        return obj_norm

    # 2. 分别读取并归一化
    try:
        # 获取归一化后的振幅 (0~1)
        amp_norm = read_process_norm(path_amp, "Amplitude")
        # 获取归一化后的相位 (0~1)
        phi_norm = read_process_norm(path_phi, "Phase")

    except Exception as e:
        print(f"加载出错: {e}")
        return np.zeros((target_size, target_size), dtype=np.complex128)

    # 3. 物理映射与合成
    print("正在合成复数物体...")
    phase = phi_norm * 2*np.pi  # 映射到 [0, π]
    # phase_physical = phi_norm * 2 * np.pi # 如果需要映射到 [0, 2π] 请解开此行

    # 合成公式: Obj = A * exp(j * phi)
    obj = amp_norm * np.exp(1j * phase)
    print(f"合成完成。复数物体范围: abs_max={np.max(np.abs(obj)):.4f}")

    return obj

def save_as_NPY(obj, save_dir, save_name):

    # 将数据保存为npy格式
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    # 保存NPY格式无损数据用于后续处理
    np.save(os.path.join(save_dir, f"{save_name}.npy"), obj)
    print(f"原始数据 (.npy) 已保存至 {save_dir}")
    print(f"max_obj = {np.max(abs(obj))}")


def save_as_PNG(obj, save_dir, save_name):
    # 将数据保存为PNG格式"   输入数据维度为多帧，提取第一帧保存.
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    img_data = obj
    if img_data.ndim > 2:
        img_data = img_data[0]
    # 保存PNG格式数据用于展示分析
    obj_uint16 = (np.clip(abs(img_data), 0, 1) * 65535).astype(np.uint16)
    cv2.imwrite(os.path.join(save_dir, f"{save_name}.png"), obj_uint16)
    print(f"原始数据 (.png) 已保存至 {save_dir}")
    print(f"max_obj = {np.max(abs(obj))}")



def generate_source(
        size_source=512,
        delta_source=50e-6,
        radius=7.6e-3,
        quadrant_mode=0, #[形状参数，描述四分之一圆所在象限]
        angle=0.0,
        sigma=0.0,
        intensity=1.0
):
    """
        生成参数化的面光源/象限光源图案

        Args:
            size_source (int): 图像像素尺寸 (N x N)
            delta_source (float): 单像素物理尺寸 (meters)
            radius (float): 光源的物理半径 (meters)
            quadrant_mode (int): 象限控制开关
                0: 完整圆形光源
                1: 第一象限 (右上, x>=0, y>=0)
                2: 第二象限 (左上, x<=0, y>=0)
                3: 第三象限 (左下, x<=0, y<=0)
                4: 第四象限 (右下, x>=0, y<=0)
            sigma (float): 高斯滤波的标准差，单位为米 (meters)
            intensity (float): 光源强度值

        Returns:
            np.ndarray: 生成的光源二维矩阵
        """
    # 1. 生成物理坐标网格 (Centered)
    y_idx, x_idx = np.ogrid[-size_source // 2:size_source // 2, -size_source // 2:size_source // 2]
    # 转换为物理坐标
    y_phy = y_idx * delta_source
    x_phy = x_idx * delta_source
    # 坐标旋转
    theta = np.deg2rad(angle)
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    x_rot = x_phy * cos_t + y_phy * sin_t
    y_rot = -x_phy * sin_t + y_phy * cos_t
    # 2. 生成基础圆形掩膜
    # mask_base: (x^2 + y^2 <= R^2)
    mask_base = (x_phy ** 2 + y_phy ** 2 <= radius ** 2)

    # 3. 处理象限截断 (Quadrant Truncation)
    mask_quad = np.zeros_like(mask_base, dtype=bool)

    if quadrant_mode == 0:
        # 全圆模式：所有区域都有效
        mask_quad[:] = True
    elif quadrant_mode == 1:
        # 第一象限: X>=0, Y>=0 (注意图像坐标系y通常向下，但物理坐标系我们通常假设y向上)
        # 这里按照常见的笛卡尔坐标系逻辑:
        mask_quad = (x_rot >= 0) & (y_rot >= 0)
    elif quadrant_mode == 2:
        # 第二象限: X<=0, Y>=0
        mask_quad = (x_rot <= 0) & (y_rot >= 0)
    elif quadrant_mode == 3:
        # 第三象限: X<=0, Y<=0
        mask_quad = (x_rot <= 0) & (y_rot <= 0)
    elif quadrant_mode == 4:
        # 第四象限: X>=0, Y<=0
        mask_quad = (x_rot >= 0) & (y_rot <= 0)
    else:
        raise ValueError("quadrant_mode must be 0, 1, 2, 3, or 4")

    # 4. 组合掩膜并赋值
    final_mask = mask_base & mask_quad

    source_data = np.zeros((size_source, size_source), dtype=float)
    source_data[final_mask] = intensity

    # 5. 物理参数滤波 (Physical Gaussian Blur)
    # 将物理尺寸 (meters) 转换为 像素尺寸 (pixels)
    if sigma > 0:
        sigma_pixel = sigma / delta_source
        source_data = gaussian_filter(source_data, sigma=sigma_pixel)

    return source_data

def generate_pattern(size=1024, num_rects=50, min_w=10, max_w=100):
    """生成类集成电路的随机矩形图案"""
    # 初始化全黑背景
    obj = np.zeros((size, size), dtype=float)

    # 随机种子，保证每次生成一样的图，方便复现
    np.random.seed(42)

    for _ in range(num_rects):
        # 随机生成矩形参数
        w = np.random.randint(min_w, max_w)
        h = np.random.randint(min_w, max_w)
        x = np.random.randint(0, size - w)
        y = np.random.randint(0, size - h)
        val = np.random.uniform(0.5, 1.0)  # 随机透射率

        # 叠加矩形 (模拟多层电路结构)
        obj[y:y + h, x:x + w] = np.maximum(obj[y:y + h, x:x + w], val)

    # 添加一些细线条模拟导线
    for _ in range(30):
        if np.random.rand() > 0.5:  # 横线
            w = np.random.randint(50, 300)
            h = np.random.randint(2, 6)
            x = np.random.randint(0, size - w)
            y = np.random.randint(0, size - h)
        else:  # 竖线
            h = np.random.randint(50, 300)
            w = np.random.randint(2, 6)
            x = np.random.randint(0, size - w)
            y = np.random.randint(0, size - h)
        obj[y:y + h, x:x + w] = 1.0

    return obj